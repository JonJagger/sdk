<?php echo phpinfo() ?> 


